window.mw.loader.testCallback = function() {
	start();
	ok( true, 'Implementing a module, is the callback timed properly ?');
};
