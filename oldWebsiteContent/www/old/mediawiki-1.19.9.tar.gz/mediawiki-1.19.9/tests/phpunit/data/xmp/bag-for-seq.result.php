<?php

$result = array(
	'xmp-general' => array(
		'Artist' => array(
			'_type' => 'ul',
			0 => 'The author',
		)
	)
);
