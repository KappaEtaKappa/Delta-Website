jQuery( function () {
	mediaWiki.Debug.init();
} );
